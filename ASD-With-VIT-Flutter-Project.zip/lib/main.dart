import 'package:flutter/material.dart';
import 'presentation/screens/onboarding_screen.dart';
import 'ui/theme/theme.dart';

void main() {
  runApp(const AsdDetectionApp());
}

class AsdDetectionApp extends StatelessWidget {
  const AsdDetectionApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ASD Detection Hub',
      theme: appTheme,
      home: const OnboardingScreen(),
    );
  }
}
