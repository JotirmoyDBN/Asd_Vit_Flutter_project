// Handles the Convolutional Neural Network model using Vision Transformers
// for the early detection of Autism Spectrum Disorder.
import 'package:tflite_flutter/tflite_flutter.dart';

class VitSeInferenceEngine {
  Interpreter? _interpreter;

  Future<void> loadModel() async {
    // Load the CNN + ViT model
    _interpreter = await Interpreter.fromAsset('assets/models/asd_vit_se_model.tflite');
  }

  Future<List<double>> analyzeImage(List<List<List<int>>> imageMatrix) async {
    if (_interpreter == null) throw Exception("Model not loaded");
    
    var output = List<double>.filled(1, 0).reshape([1, 1]);
    _interpreter!.run(imageMatrix, output);
    return output[0];
  }
}
