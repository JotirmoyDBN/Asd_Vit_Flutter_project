import 'package:flutter/material.dart';

class DetectionHubScreen extends StatelessWidget {
  const DetectionHubScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Detection Hub')),
      body: const Center(child: Text('Upload Image for ASD ViT Inference')),
    );
  }
}
