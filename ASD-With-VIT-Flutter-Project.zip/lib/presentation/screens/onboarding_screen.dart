import 'package:flutter/material.dart';
import 'detection_hub_screen.dart';

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ElevatedButton(
          onPressed: () => Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (_) => const DetectionHubScreen())
          ),
          child: const Text('Start ASD Screening'),
        ),
      ),
    );
  }
}
