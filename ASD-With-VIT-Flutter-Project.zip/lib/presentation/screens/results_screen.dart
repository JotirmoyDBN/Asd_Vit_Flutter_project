import 'package:flutter/material.dart';

class ResultsScreen extends StatelessWidget {
  final double score;
  const ResultsScreen({Key? key, required this.score}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Results')),
      body: Center(child: Text('Risk Score: $score')),
    );
  }
}
