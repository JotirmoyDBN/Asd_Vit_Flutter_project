import 'package:flutter/material.dart';

class AnatomicalFaceOverlay extends StatelessWidget {
  const AnatomicalFaceOverlay({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(border: Border.all(color: Colors.red)),
      child: const Text('Face Overlay Guide'),
    );
  }
}
