import 'package:flutter/material.dart';

class AttentionHeatmapView extends StatelessWidget {
  const AttentionHeatmapView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Placeholder(fallbackHeight: 200, fallbackWidth: 200);
  }
}
