import 'package:flutter/material.dart';

class RiskScoreGauge extends StatelessWidget {
  final double score;
  const RiskScoreGauge({Key? key, required this.score}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CircularProgressIndicator(value: score);
  }
}
