import 'package:flutter/material.dart';

class ClinicalMetricBar extends StatelessWidget {
  const ClinicalMetricBar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const LinearProgressIndicator(value: 0.5);
  }
}
