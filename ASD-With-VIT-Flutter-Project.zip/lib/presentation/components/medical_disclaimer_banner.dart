import 'package:flutter/material.dart';

class MedicalDisclaimerBanner extends StatelessWidget {
  const MedicalDisclaimerBanner({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.amber,
      padding: const EdgeInsets.all(8),
      child: const Text('Not a medical diagnosis. Consult a professional.'),
    );
  }
}
