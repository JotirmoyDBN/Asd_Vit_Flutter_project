import 'package:flutter/foundation.dart';
import '../../core/ml/vit_se_inference_engine.dart';
import '../../data/repository/screening_repository.dart';

class ScreeningViewModel extends ChangeNotifier {
  final VitSeInferenceEngine _engine = VitSeInferenceEngine();
  final ScreeningRepository _repository = ScreeningRepository();
  
  bool isProcessing = false;
  double? currentRiskScore;

  Future<void> processImage(List<List<List<int>>> image) async {
    isProcessing = true;
    notifyListeners();

    final result = await _engine.analyzeImage(image);
    currentRiskScore = result.first;
    await _repository.saveResult(currentRiskScore!);

    isProcessing = false;
    notifyListeners();
  }
}
