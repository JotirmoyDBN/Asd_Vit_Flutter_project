class ClinicalMetric {
  final String label;
  final double value;

  ClinicalMetric(this.label, this.value);
}
