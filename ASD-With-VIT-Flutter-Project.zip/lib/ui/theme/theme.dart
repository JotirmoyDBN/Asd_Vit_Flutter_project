import 'package:flutter/material.dart';
import 'color.dart';
import 'type.dart';

final appTheme = ThemeData(
  primaryColor: primaryColor,
  textTheme: appTextTheme,
  colorScheme: ColorScheme.fromSwatch().copyWith(secondary: secondaryColor),
);
