import '../database/app_database.dart';
import '../entity/screening_assessment_entity.dart';

class ScreeningDao {
  final AppDatabase _db = AppDatabase();

  Future<void> insertScreening(ScreeningAssessmentEntity entity) async {
    final db = await _db.database;
    await db.insert('screenings', entity.toMap());
  }
}
