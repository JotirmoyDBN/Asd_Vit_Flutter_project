class ScreeningAssessmentEntity {
  final int? id;
  final double riskScore;
  final DateTime timestamp;

  ScreeningAssessmentEntity({this.id, required this.riskScore, required this.timestamp});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'riskScore': riskScore,
      'timestamp': timestamp.toIso8601String(),
    };
  }
}
