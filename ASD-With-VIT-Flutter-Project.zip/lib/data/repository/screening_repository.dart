import '../local/dao/screening_dao.dart';
import '../local/entity/screening_assessment_entity.dart';

class ScreeningRepository {
  final ScreeningDao _dao = ScreeningDao();

  Future<void> saveResult(double score) async {
    final entity = ScreeningAssessmentEntity(riskScore: score, timestamp: DateTime.now());
    await _dao.insertScreening(entity);
  }
}
